﻿define(['app', 'service'], function (app) {
    app.controller("EmployeeCtrl", function ($scope, userService, ProductEmployee) {
         $scope.editMode = false;
         $scope.selecteColor = "";
        //get User
        $scope.get = function () {
            $scope.user = this.user;
            $("#viewModal").modal('show');
        };

        // initialize your users data
        (function () {
            ProductEmployee.GetEmployeeProducts().success(function (data) {
                $scope.Employees = data;
            }).error(function (data) {
                $scope.error = "An Error has occured while Loading users! " + data.ExceptionMessage;
            });
        })();

        // add User
        $scope.selectProduct = function (id) {
            var currentEmployees = this.Employees;
            currentEmployees.SelEmployee_id = id;
            $scope.selecteColor = "";
            if (currentEmployees.EmployeeList[id-1] != null) $scope.selecteColor = currentEmployees.EmployeeList[id-1].Employee_Color;
            ProductEmployee.GetEmployee2Products(currentEmployees).success(function (data) {
                $scope.Employees = data;
             
            }).error(function (data) {
                $scope.error = "An Error has occured while Loading users! " + data.ExceptionMessage;
            });

           
        };

        $scope.SelectEmployeeColor = function (id) {
            var currentEmployees = this.Employees;
            currentEmployees.ProductList[id-1].Employee_Color = $scope.selecteColor;
            $scope.editMode = true;
        }

        //update user
        $scope.update = function () {
            var currentEmployees = $scope.Employees;
            userService.updateUser(currentEmployees).success(function (data) {
                currentEmployees.editMode = false;               
            }).error(function (data) {
                $scope.error = "An Error has occured while Updating user! " + data.ExceptionMessage;
            });
        };

       

      
    });
});
