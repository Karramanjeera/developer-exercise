﻿using MobileService.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;

namespace MobileService.Controllers
{
     [EnableCors("*", "*", "*")]
    public class ProductEmployeeController : ApiController
    {
         private const string CONNECTION_STRING_KEY = "TESTData";
        private SqlConnection _sqlConn;
        public SqlConnection SqlConn
        {
            get
            {
                if ((_sqlConn == null))
                {
                    _sqlConn = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings[CONNECTION_STRING_KEY].ConnectionString);
                }
                return _sqlConn;
            }
            set
            {
                _sqlConn = value;
            }
        }

        [HttpGet]
        public EmployeeProduct GetEmployeeProducts()
        {
            EmployeeProduct ep = new EmployeeProduct();
            ep.EmployeeList = GetEmployees();
            ep.ProductList = GetProducts();
            return ep;            
        }

        private List<Employee> GetEmployees()
        {
            List<Employee> EmployeeList = new List<Employee>();

            int returnValue = 0;
            SqlConn.Open();
            string oCmdString = "GetEmployees";
            SqlCommand oCmd = new SqlCommand(oCmdString, SqlConn);
            oCmd.CommandType = CommandType.StoredProcedure;
            oCmd.Parameters.Add("@ReturnValue", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
            SqlDataReader dr = oCmd.ExecuteReader(CommandBehavior.CloseConnection);

            while (dr.Read())
            {
                Employee e = new Employee();
                e.Employee_Name = Convert.ToString(dr["Employee_Name"]);
                e.Employee_Color = Convert.ToString(dr["Employee_Color"]);
                e.Employee_Id = Convert.ToInt32(dr["Employee_Id"]);
                EmployeeList.Add(e);
            }

            returnValue = Convert.ToInt32(oCmd.Parameters["@ReturnValue"].Value);
            SqlConn.Close();

            if (returnValue != 0)
            {
                throw new Exception("The ConsPersons.ConsPersonsRetrieveNameByPersonID method received an error");
            }

            return EmployeeList;
        }

        [HttpGet]
        public List<Product> GetProducts()
        {
            List<Product> ProductList = new List<Product>();

            int returnValue = 0;
            SqlConn.Open();
            string oCmdString = "GetProducts";
            SqlCommand oCmd = new SqlCommand(oCmdString, SqlConn);
            oCmd.CommandType = CommandType.StoredProcedure;
            oCmd.Parameters.Add("@ReturnValue", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
            SqlDataReader dr = oCmd.ExecuteReader(CommandBehavior.CloseConnection);

            while (dr.Read())
            {
                Product p = new Product();
                p.Product_Id = Convert.ToInt32(dr["Product_Id"]);
                p.Product_Name = Convert.ToString(dr["Product_Name"]);
                ProductList.Add(p);
            }
            returnValue = Convert.ToInt32(oCmd.Parameters["@ReturnValue"].Value);
            SqlConn.Close();

            if (returnValue != 0)
            {
                throw new Exception("The ConsPersons.ConsPersonsRetrieveNameByPersonID method received an error");
            }

            return ProductList;
        }

        [HttpPost]
        public EmployeeProduct GetEmployee2Products(EmployeeProduct ep)
        {
            for(int i=0; i<ep.ProductList.Count; i++)
            {
               ep.ProductList[i].Employee_Color = "";
               ep.ProductList[i].Active_Flag = false;
            }
            //ep.SelProducts SelProducts = new List<SelProducts>();
            int returnValue = 0;
            SqlConn.Open();
            string oCmdString = "GetEmployee2Products";
            SqlCommand oCmd = new SqlCommand(oCmdString, SqlConn);
            oCmd.CommandType = CommandType.StoredProcedure;
            oCmd.Parameters.Add("@ReturnValue", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
            oCmd.Parameters.AddWithValue("@Employee_Id", Convert.ToInt32(ep.SelEmployee_id));
            SqlDataReader dr = oCmd.ExecuteReader(CommandBehavior.CloseConnection);

            while (dr.Read())
            {
                Product CurrentProduct = ep.ProductList.Find(x => x.Product_Id == Convert.ToInt32(dr["Product_Id"]));
                if (CurrentProduct!=null)
                {
                    CurrentProduct.Employee_Color = Convert.ToString(dr["Employee_Color"]);
                    CurrentProduct.Active_Flag = Convert.ToBoolean(dr["Active_Flag"]);
                }
                else
                {

                }
              //  ep.SelProducts.Add(sp);
            }
            returnValue = Convert.ToInt32(oCmd.Parameters["@ReturnValue"].Value);
            SqlConn.Close();

            if (returnValue != 0)
            {
                throw new Exception("The ConsPersons.ConsPersonsRetrieveNameByPersonID method received an error");
            }

            return ep;
        }


        //[HttpPost]
        //public EmployeeProduct SaveEmployee2Products(EmployeeProduct ep)
        //{
          
        //}
    }
}