﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MobileService.Models
{
    public class EmployeeProduct
    {
        public int SelEmployee_id { get; set; }
        public List<Employee> EmployeeList { get; set; }
        public List<Product> ProductList { get; set; }
        public List<SelProducts> SelProducts { get; set; }
        public EmployeeProduct()
        {
            EmployeeList = new List<Employee>();
            ProductList = new List<Product>();
            SelProducts = new List<SelProducts>();
        }

    }
    public class SelProducts
    {
        public int Product_Id { get; set; }
        public string Employee_Color { get; set; }

        public SelProducts()
        {
            Product_Id = 0;
            Employee_Color = "";
        }
    }
}