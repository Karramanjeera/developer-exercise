﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MobileService.Models
{
    public class Employee
    {
        public int Employee_Id { get; set; }

        public string Employee_Name { get; set; }
        public string Employee_Color { get; set; }
        public int Manager_Id { get; set; }

        public Employee()
        {
            Employee_Id = 0;
            Employee_Name = "";
            Employee_Color = "";
            Manager_Id = 0;
        }
    }
}